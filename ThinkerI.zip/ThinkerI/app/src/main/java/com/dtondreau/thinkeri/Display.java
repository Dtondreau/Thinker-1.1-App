package com.dtondreau.thinkeri;

import android.app.Activity;
import android.app.Notification;
import android.os.Bundle;

/**
 * Created by stadmin on 3/28/2016.
 */
public class Display extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display);
    }

}
