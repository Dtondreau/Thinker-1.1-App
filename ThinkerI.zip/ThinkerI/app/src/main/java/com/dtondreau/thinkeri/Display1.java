package com.dtondreau.thinkeri;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by stadmin on 3/28/2016.
 */
public class Display1 extends Activity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.display1);
        }

    }

